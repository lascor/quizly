=Quizly=

==Disclaimer==
This Little Project is an Assingment for the Module 256: "Clientseitige Anwendung realisieren" directed by 

==Function==
This Project is a litte Quizapp where you can add/edit/delete your own Questions and Question Modules.
Requirement is it is only written in javascript so no Persistance now :D


==Paticipants==

Oliver Widemann
Patrick Jan Kiefer aka. "Lascor"